/*
Theme Name: Hannari Pink
Author: PWT
Theme URI: http://www.pwtthemes.com/theme/hannari-free-responsive-wordpress-theme
Author URI: http://www.stefanciobanu.com
Description: Hannari Pink is a child theme for the Hannari theme. Hannari is a fully responsive, flexible, simple and beautiful. This theme have a really cool and a lot of theme options, possibility of creating multiple sidebar
Version: 1.0.4
Tags: pink, black, white, light, one-column, two-columns, left-sidebar, right-sidebar, fluid-layout, responsive-layout, custom-menu, custom-background, editor-style, featured-images, full-width-template, theme-options, threaded-comments, sticky-post
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Template: hannari
*/

== Copyright ==
Hannari Pink, Copyright 2013 www.pwtthemes.com
Hannari Pink is distributed under the terms of the GNU GPL

== Installation ==

1. Upload the `hannari-pink` folder to the `/wp-content/themes/` directory
Activation and Use
1. Activate the Theme through the 'Themes' menu in WordPress
2. See Appearance -> Theme Options to change theme options